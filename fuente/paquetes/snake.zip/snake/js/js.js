var timer;
    window.onload=function(){
        createGrass();
        createSnake();
        createFood();
        document.getElementById('start').onclick=function(){
            clearInterval(timer);
            timer=setInterval(function(){
                snakeMove(diRection);
            },150);
            snakeMove(diRection);
        };
        document.getElementById('pause').onclick=function(){
            clearInterval(timer);
        };
    };
    function createGrass(){
        var oGround=document.getElementById('ground');
        var oDiv;
        for(var i=0;i<50;i++){
            for(var j=0;j<25;j++){
                oDiv=document.createElement('div');
                oDiv.className='block';
                oGround.appendChild(oDiv);
            }
        }
    }
    var snakeBody=[],oFood,diRection='left';
    function createSnake(){
        var oGround=document.getElementById('ground');
        var oDiv;
        for(var i=0;i<3;i++){
            oDiv=document.createElement('div');
            oDiv.className='snakeBody';
            oDiv.style.left=(i+40)*20+'px';
            oDiv.style.top='60px';
            oGround.appendChild(oDiv);
            snakeBody.push(oDiv);
        }
    }
    function createFood(){
        var flag=true; 
        var oGround=document.getElementById('ground');
        var len=snakeBody.length;
        var iLeft,iTop;
        oFood=document.createElement('div');
        oFood.className='food';
        iLeft=parseInt(Math.random()*49)*20;
        iTop=parseInt(Math.random()*24)*20;
        for(var i=0;i<len;i++){
            if(snakeBody[i].offsetLeft == iLeft && snakeBody[i].offsetTop == iTop){
                flag=false;
                break;
            }
        }
        if(flag==true){
            oFood.style.left=iLeft+'px';
            oFood.style.top=iTop+'px';
            oGround.appendChild(oFood);
        }else{
            createFood();
        }
    }

    function snakeMove(direction){
        var snakeHead=snakeBody[0];
        diRection=direction;
        for(var i=snakeBody.length-1;i>0;i--){
            snakeBody[i].style.left=snakeBody[i-1].offsetLeft+'px';
            snakeBody[i].style.top=snakeBody[i-1].offsetTop+'px';
        }
        switch (direction){
            case 'left':snakeHead.style.left=snakeHead.offsetLeft-20+'px';break;
            case 'right':snakeHead.style.left=snakeHead.offsetLeft+20+'px';break;
            case 'up':snakeHead.style.top=snakeHead.offsetTop-20+'px';break;
            case 'down':snakeHead.style.top=snakeHead.offsetTop+20+'px';break;
        }
        if(snakeHead.offsetLeft == -20 || snakeHead.offsetLeft == 1000 || snakeHead.offsetTop == -20 || snakeHead.offsetTop == 500){
            clearInterval(timer);
            if(confirm('Otra partida?')){
                window.location.reload();
            }
        }
        for(var j=1;j<snakeBody.length;j++){
            if(snakeHead.offsetLeft == snakeBody[j].offsetLeft && snakeHead.offsetTop == snakeBody[j].offsetTop){
                clearInterval(timer);
                if(confirm('Otra vez')){
                    window.location.reload();
                }
            }
        }

        if(snakeHead.offsetLeft==oFood.offsetLeft && snakeHead.offsetTop==oFood.offsetTop){
            oFood.className='snakeBody snake-block';
            console.log(snakeBody[snakeBody.length-1].offsetTop);
            switch (direction){
                case 'left':oFood.style.left=snakeBody[snakeBody.length-1].offsetLeft+'px';break;
                case 'right':oFood.style.left=snakeBody[snakeBody.length-1].offsetLeft+'px';break;
                case 'up':oFood.style.top=snakeBody[snakeBody.length-1].offsetTop+'px';break;
                case 'down':oFood.style.top=snakeBody[snakeBody.length-1].offsetTop+'px';break;
            }
            snakeBody.push(oFood);
            createFood();
        }
    }

    document.onkeydown=function(e){
        var event=e || window.event;
        var direction=event.keyCode;
        switch (direction){
            case 37:
                if(diRection != 'right'){
                    snakeMove('left');
                }
            break;  
            case 39:
                if(diRection != 'left'){
                    snakeMove('right');
                }
            break;
            case 38:
                if(diRection != 'down'){
                    snakeMove('up');
                }
            break;
            case 40:if(diRection != 'up'){
                snakeMove('down');
            }
            break;
        }
    }