const vm = new Vue({
    el: '#sum',
    data() {
        return {
            flag: ['0s', '1s', '2s', '3s', '4s', '5s', '6s', '7s', '8s', '9s', '10s', ' 11s', '12s', '13s', '14s', '15s', '16s', '17s', '18s', '19s', '20s', '21s', '22s', '23s', '24s', '25s', '26s', '27s', '28s', '29s', '30s', '31s', '32s', '33s', '34s', '35s', '36s', '37s', '38s', '39s', '40s', '41s', '42s', '43s', '44s', '45s', '46s', '47s', '48s', '49s', '50s', '51s', '52s', '53s', '54s', '55s', '56s', '57s', '58s', '59s'],
            flag_minute: ['0min', '1min', '2min', '3min', '4min', '5min', '6min', '7min', '8min', '9min', '10min', ' 11min', '12min', '13min', '14min', '15min', '16min', '17min', '18min', '19min', '20min', '21min', '22min', '23min', '24min', '25min', '26min', '27min', '28min', '29min', '30min', '31min', '32min', '33min', '34min', '35min', '36min', '37min', '38min', '39min', '40min', '41min', '42min', '43min', '44min', '45min', '46min', '47min', '48min', '49min', '50min', '51min', '52min', '53min', '54min', '55min', '56min', '57min', '58min', '59min'],
            flag_hour: ['12Hora', '1Hora', '2Hora', '3Hora', '4Hora', '5Hora', '6Hora', '7Hora', '8Hora', '9Hora', '10Hora', '11Hora'],
            flag_mouth: [{
                name: 'Enero',
                flag: false
            }, {
                name: 'Febrero',
                flag: false
            }, {
                name: 'Marzo',
                flag: false
            }, {
                name: 'Abril',
                flag: false
            }, {
                name: 'Mayo',
                flag: false
            }, {
                name: 'Juny',
                flag: false
            }, {
                name: 'Julio',
                flag: false
            }, {
                name: 'Agosto',
                flag: false
            }, {
                name: 'Septiembre',
                flag: false
            }, {
                name: 'Octubre',
                flag: false
            }, {
                name: 'Noviembre',
                flag: false
            }, {
                name: 'Diciembre',
                flag: false
            }],
            flag_solar: [{
                name: 'Primav.',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: 'Verano',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: 'Otoño',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: 'Invierno',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }, {
                name: ' ',
                flag: false,
                msg: '                                      '
            }],
            Arrays: [],
            flag_data: [{
                name: 'Dia 1',
                flag: false
            }, {
                name: 'Dia 2',
                flag: false
            }, {
                name: 'Dia 3',
                flag: false
            }, {
                name: ' Dia 4',
                flag: false
            }, {
                name: 'Dia 5',
                flag: false
            }, {
                name: 'Dia 6',
                flag: false
            }, {
                name: 'Dia 7',
                flag: false
            }, {
                name: 'Dia 8',
                flag: false
            }, {
                name: 'Dia 9',
                flag: false
            }, {
                name: ' Dia 10',
                flag: false
            }, {
                name: 'Dia 11',
                flag: false
            }, {
                name: '  Dia 12',
                flag: false
            }, {
                name: '   Dia 13',
                flag: false
            }, {
                name: '    Dia 14',
                flag: false
            }, {
                name: '   Dia 15',
                flag: false
            }, {
                name: ' Dia 16',
                flag: false
            }, {
                name: '  Dia 17',
                flag: false
            }, {
                name: '   Dia 18',
                flag: false
            }, {
                name: '    Dia 19',
                flag: false
            }, {
                name: '     Dia 20',
                flag: false
            }, {
                name: 'Dia 21',
                flag: false
            }, {
                name: ' Dia 22',
                flag: false
            }, {
                name: '  Dia 23',
                flag: false
            }, {
                name: '   Dia 24',
                flag: false
            }, {
                name: 'Dia 25',
                flag: false
            }, {
                name: ' Dia 26',
                flag: false
            }, {
                name: ' Dia 27',
                flag: false
            }, {
                name: '  Dia 28',
                flag: false
            }, {
                name: '   Dia 29 ',
                flag: false
            }, {
                name: '   Dia 30 ',
                flag: false
            }, {
                name: '   Dia 31 ',
                flag: false
            }],
            flag_AP: [{
                name: 'Mañan.'
            }, {
                name: 'Tarde'
            }],
            NllNumber: []
        }
    },
    methods: {
        showMsg: function(index) {
            var this_ = this
            var sum = this_.flag_solar
            var a = 0
            var b = 12
            var newObject
            var strings = sum[index].msg
            var arrayy = strings.split('')
            var length = arrayy.length
            var arrayOne
            var stringOne = ''
            for (var i = 0; i < 10; i++) {
                arrayOne = arrayy.slice(a, b)
                if (arrayOne.length !== 0) {
                    stringOne = arrayOne.join()
                    newObject = stringOne.replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '').replace(',', '')
                    this.Arrays.push(newObject)
                }
                if (i === 0) {
                    a += 12
                    b += 20
                } else {
                    a += 20
                    b += 20
                }
            }
        },
        hideMsg: function() {
            this.Arrays = []
            this.NllNumber = []
        }
    }
})
var number = 0

function sell() {
    var data = new Date()
    var second = data.getSeconds() + 1
    number = second * -6
    document.getElementById('second').setAttribute('style', '-webkit-transform:rotate' + '(' + number + 'deg)')
    var myVar = setInterval(function() {
        sell_one()
    }, 1000)
}

function sell_one() {
    document.getElementById('second').setAttribute('style', '-webkit-transform:rotate' + '(' + number + 'deg)')
    number += -6
}
sell()
var number_minute = 0

function minutes() {
    var myVar = setInterval(function() {
        sell_two()
    }, 1000)
}

function sell_two() {
    var data = new Date()
    var minute = data.getMinutes()
    number_minute = minute * -6
    document.getElementById('minute').style.webkitTransform = 'rotate' + '(' + number_minute + 'deg)'
}
minutes()
var number_hour = 0

function hours() {
    var myVar = setInterval(function() {
        sell_three()
    }, 1000)
}

function sell_three() {
    var data = new Date()
    var hour = data.getHours()
    number_hour = hour * -30
    document.getElementById('hour').style.webkitTransform = 'rotate' + '(' + number_hour + 'deg)'
}
hours()

function year() {
    var data = new Date()
    var year = data.getFullYear()
    document.getElementById('yearAll').innerHTML = year + 'Año'
}
year()

function solarAndMouth() {
    var data = new Date()
    var mouth = data.getMonth()
    var number_mouth = mouth * -30
    document.getElementById('mouth').style.webkitTransform = 'rotate' + '(' + number_mouth + 'deg)'
    document.getElementById('solar').style.webkitTransform = 'rotate' + '(' + number_mouth + 'deg)'
}
solarAndMouth()

function dates() {
    var data = new Date()
    var date = data.getDate()
    var number_date = date * -11.25 + 11.25
    document.getElementById('data').style.webkitTransform = 'rotate' + '(' + number_date + 'deg)'
}
dates()

function APS() {
    var data = new Date()
    var ap = data.getHours()
    if (ap > 12) {
        document.getElementById('AP').style.webkitTransform = 'rotate(180deg)'
    } else {
        document.getElementById('AP').style.webkitTransform = 'rotate(0deg)'
    }
}
APS()